﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[XmlRoot]
public class GameSaveData 
{
    public static GameSaveData Instance;

    //[XmlAttribute]
    //public int SceneID;
    //public float PosX;
    //public float PosY;
    //public float PosZ;
    //public float MainVol;
    //public float SoundEffectVol;
    //public float DialogueVol;
    //public bool FullscreenMode;
    //public string ResolutionString;
    //public int AA_Setting;
    //public string ShadowSetting;

    [XmlArray("Scene")]
    [XmlArrayItem("CurrentSceneID")]
    public int SceneID { get; set; }

    [XmlArray("Player")]
    [XmlArrayItem("PosX")]
    public float PosX { get; set; }
    [XmlArrayItem("PosY")]
    public float PosY { get; set; }
    [XmlArrayItem("PosZ")]
    public float PosZ { get; set; }

    [XmlArray("AudioSettings")]
    [XmlArrayItem("MainVol")]
    public float MainVol { get; set; }
    [XmlArrayItem("SoundEffectVol")]
    public float SoundEffectVol { get; set; }
    [XmlArrayItem("DialogueVol")]
    public float DialogueVol { get; set; }

    [XmlArray("GraphicsSettings")]
    [XmlArrayItem("FullscreenTog")]
    public bool FullscreenMode { get; set; }
    [XmlArrayItem("ResolutionString")]
    public string ResolutionString { get; set; }
    [XmlArrayItem("AA_Setting")]
    public int AA_Setting { get; set; }
    [XmlArrayItem("ShadowSetting")]
    public string ShadowSetting{ get; set; }

    [XmlArray("")]
    [XmlArrayItem("")]
    public bool LevelOneOne { get; set; }
    [XmlArrayItem("")]
    public bool LevelOneTwo { get; set; }
    [XmlArrayItem("")]
    public bool LevelOneThree { get; set; }
    [XmlArrayItem("")]
    public bool LevelTwoOne { get; set; }
    [XmlArrayItem("")]
    public bool LevelTwoTwo { get; set; }
    [XmlArrayItem("")]
    public bool LevelTwoThree { get; set; }
    [XmlArrayItem("")]
    public bool LevelThreeOne { get; set; }
    [XmlArrayItem("")]
    public bool LevelThreeTwo { get; set; }
    [XmlArrayItem("")]
    public bool LevelThreeThree{ get; set; }
    [XmlArrayItem("")]
    public bool LevelFourOne{ get; set; }
    [XmlArrayItem("")]
    public bool LevelFourTwo { get; set; }
    [XmlArrayItem("")]
    public bool LevelFourThree { get; set; }
    [XmlArrayItem("")]
    public bool LevelFiveOne { get; set; }
    [XmlArrayItem("")]
    public bool LevelFiveTwo { get; set; }
    [XmlArrayItem("")]
    public bool LevelFiveThree { get; set; }
    [XmlArrayItem("")]
    public bool LevelSixOne { get; set; }
    [XmlArrayItem("")]
    public bool LevelSixTwo { get; set; }
    [XmlArrayItem("")]
    public bool LevelSixThree { get; set; }

    public void ConsolidateInfo()
    {

    }
}
