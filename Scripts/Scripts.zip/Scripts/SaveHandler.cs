﻿using UnityEngine;
using System.Collections;
using System.Xml;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;

//References:
//http://unitynoobs.blogspot.ca/2011/04/xml-writing-to-existing-xml-file.html
//http://answers.unity3d.com/questions/8480/how-to-scrip-a-saveload-game-option.html

public static class SaveHandler
{
    

    public static void Save()
    {
        string filepath = Application.dataPath + "";
        XmlDocument xmlDoc = new XmlDocument();

        if(File.Exists(filepath))
        {
            xmlDoc.Load(filepath);

            XmlElement elmRoot = xmlDoc.DocumentElement;
        }

    }

    public static void Load()
    {

    }
}
