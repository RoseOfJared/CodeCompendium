﻿using UnityEngine;
using System.Collections;

public static class DebugTools 
{
    public static void ShowFPS() { }
    public static void ShowColliders() { }
    public static void SkeletonKey() { }
}
