﻿using UnityEngine;
using System.Collections;

public class HudHandler : MonoBehaviour {

    public static HudHandler Instance;

    // Use this for initialization
    void Start ()
    {
        if (Instance == null)
        {
            //This tells unity not to delete the object when you load another scene
            DontDestroyOnLoad(gameObject);
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }
	
	// Update is called once per frame
	void Update ()
    {
	
	}
}
