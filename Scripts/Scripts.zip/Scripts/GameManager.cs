﻿using UnityEngine;
using System.Collections;
using System.Xml;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using UnityEngine.SceneManagement;

[System.Serializable]
public class GameManager : MonoBehaviour {

    public static GameManager Instance;
    
    //this will happen later when I finalize the player prefab, but i think should be ok for now
    public GameObject PlayerPrefab;
    public GameObject PauseMenuPtr;
    public bool m_InCutscene = false;
    public bool m_Paused = false;
    public bool m_InMenu = false;
    public bool m_IsDebug = false;

    // Use this for initialization
    void Start ()
    {
        OnLevelWasLoaded(SceneManager.GetActiveScene().buildIndex);

        if (Instance == null)
        {
            //This tells unity not to delete the object when you load another scene
            DontDestroyOnLoad(gameObject);
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }
	
	// Update is called once per frame
	void Update () 
    {
        
        PauseHandle();
	}

    void PauseHandle()
    {
        //PauseMenuPtr = FindObjectOfType<PauseMenu>();
        if (Input.GetButtonDown("Escape"))
        {
            m_Paused = !m_Paused;
            if (m_Paused == true)
            {
                Time.timeScale = 0.0f;
                GameObject.FindWithTag("Player").GetComponent<PlayerMoveHandler>().enabled = false;
                GameObject.Find("Main Camera").GetComponent<PlayerCamHandler>().enabled = false;
                m_InMenu = true;
            }
        }


        if (m_Paused == false)
        {
            Time.timeScale = 1.0f;
            m_Paused = false;
            GameObject.FindWithTag("Player").GetComponent<PlayerMoveHandler>().enabled = true;
            GameObject.Find("Main Camera").GetComponent<PlayerCamHandler>().enabled = true;
            m_InMenu = false;
        }

        if (m_InMenu == true)
        {
            //PauseMenuPtr.SetActive(true);
            PauseMenuPtr.gameObject.SetActive(true);
        }
        else
        {
            //PauseMenuPtr.SetActive(false);
            PauseMenuPtr.gameObject.SetActive(false);

        }
    }

    void OnLevelWasLoaded(int level)
    {
        GameObject SpawnPoint = GameObject.Find("Spawn Point");
        //GameObject PauseMenuScene = GameObject.Find("PauseMenuHolder");

        GameObject playerSpawn = (GameObject)Instantiate(PlayerPrefab, SpawnPoint.transform.position, Quaternion.identity);
        m_PlayerInstance = playerSpawn;
        GetComponent<LevelTransitionEffect>().enabled = false;
        GetComponent<LevelTransitionEffect>().enabled = true;
    }

    public void Save(string path)
    {
        var serializer = new XmlSerializer(typeof(GameSaveData));
        var stream = new FileStream(path, FileMode.Open);
        serializer.Serialize(stream, this);
        stream.Close();
    }
    public void Load(string path)
    {
        var serializer = new XmlSerializer(typeof(GameSaveData));
        var stream = new FileStream(path, FileMode.Open);
        var container = serializer.Deserialize(stream) as GameSaveData;
        stream.Close();
    }

    public static GameObject m_PlayerInstance;
}
