﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class ObjLevelTransition : MonoBehaviour {

    public string LevelToTransTo;
    private bool m_IsPlayerNear;

    void OnTriggerEnter(Collider collide)
    {
        if(collide.tag == "Player")
        {
            m_IsPlayerNear = true;
        }
    }

    void OnTriggerExit(Collider collide)
    {
        if (collide.tag == "Player")
        {
            m_IsPlayerNear = false;
        }
    }

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
    {
	    if(Input.GetButtonDown("Interact") && m_IsPlayerNear)
        {
            TransToLevel();
        }
	}

    void TransToLevel()
    {
        //Application.LoadLevel(LevelToTransTo);
        SceneManager.LoadScene(LevelToTransTo);
        
    }
}
