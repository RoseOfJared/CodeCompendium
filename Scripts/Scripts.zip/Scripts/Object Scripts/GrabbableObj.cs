﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GrabbableObj : ObjInteractable {

    bool m_IsObjectNear;
    bool m_IsObjectGrabbed;
    public Text DebugText;
    public string objName;
    private Transform PlayerGrabPoint;

    void OnTriggerEnter(Collider collide)
    {
        if (collide.tag == "Player")
        {
            Debug.Log("boop");
            m_IsObjectNear = true;
        }
    }
     
	// Use this for initialization
	void Start () 
    {
        StartCoroutine(MakeYellStop_cr());
	}
	
	// Update is called once per frame
	void Update () 
    {
        
        if(m_IsObjectNear)
        {
            DebugText.text = objName;
        }

        if (Input.GetButtonDown("Interact") && m_IsObjectNear)
        {
            m_IsObjectGrabbed = !m_IsObjectGrabbed;
        }

        if(m_IsObjectGrabbed)
        {
            transform.position = PlayerGrabPoint.position;
            GetComponent<Rigidbody>().freezeRotation = true;
        }
        

	}

    public override void GrabObjectExt(bool isObjectNear, Transform GrabPoint)
    {
        this.transform.position = GrabPoint.position;
        GetComponent<Rigidbody>().freezeRotation = true;
    }

    void OnTriggerExit(Collider collide)
    {
        if (collide.tag == "Player")
        {
            Debug.Log("false boop");

            m_IsObjectNear = false;
        }
    }

    private IEnumerator MakeYellStop_cr()
    {
        yield return new WaitForEndOfFrame();
        m_IsObjectNear = false;
        m_IsObjectGrabbed = false;
        PlayerGrabPoint = GameObject.FindWithTag("Grab Point").transform;
    }
    
}
