﻿using UnityEngine;
using System.Collections;

public class OpenableObj : MonoBehaviour {

    bool m_IsOpenable;
    bool m_IsObjectNear;
    bool m_IsOpen;
    bool m_PosLeftOpen;
    bool m_PosRightOpen;
    bool m_DoorStatus;
    public Animator DoorAnimator;
    public BoxCollider Trigger;

    //float doorAngle = 90.0f;

    void OnTriggerEnter(Collider collide)
    {
        if (collide.tag == "Player")
        {
            m_IsObjectNear = true;
        }
    }

    void OnTriggerExit(Collider collide)
    {
        if (collide.tag == "Player")
        {
            m_IsObjectNear = false;
        }
    }

    // Use this for initialization
    void Start ()
    {
        m_IsOpen = false;
        InvokeRepeating("PostStatus", 2.0f, 2.0f);
    }
	
	// Update is called once per frame
	void Update ()
    {
        m_DoorStatus = DoorAnimator.GetBool("Closed");

        if(Input.GetButtonDown("Interact") && m_IsObjectNear)
        {
            if(m_DoorStatus == true)
            {
                DoorAnimator.SetBool("Closed", false);
                DoorAnimator.SetBool("LeftOpen", true);
            }

            if(m_DoorStatus == false)
            {
                DoorAnimator.SetBool("Closed", true);
                DoorAnimator.SetBool("LeftOpen", false);
            }
            
        }
    }

    void PostStatus()
    {
        Debug.Log("Current Status: " + m_IsObjectNear);
        Debug.Log("Current Door Status: " + m_DoorStatus); 
    }
}
