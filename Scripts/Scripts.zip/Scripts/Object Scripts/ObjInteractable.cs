﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ObjInteractable : MonoBehaviour
{
    public virtual void OpenDoor(bool isDoorOpen) { }
    public virtual void GrabObject(bool isObjectNear, Transform GrabPoint) { }
    public virtual void GrabObjectExt(bool isObjectNear, Transform GrabPoint) { }
    public virtual void FlipSwitch(bool isSwitchOn) { }

}
