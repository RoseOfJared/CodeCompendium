﻿using UnityEngine;
using System.Collections;

public class FlipableObj : MonoBehaviour {

    bool m_IsObjectNear;
    bool m_IsObjectGrabbed;

    bool m_IsOnState;
    bool m_IsOffState;
    public Renderer buttonRend;



    void OnTriggerEnter(Collider collide)
    {
        if (collide.tag == "Player")
        {
            m_IsObjectNear = true;
        }
    }

    void OnTriggerExit(Collider collide)
    {
        if (collide.tag == "Player")
        {
            m_IsObjectNear = false;
        }
    }

	// Use this for initialization
	void Start () 
    {
        m_IsOnState = false;
        m_IsOffState = true;
        buttonRend.material.color = Color.red;
        m_IsObjectNear = false;
	}
	
	// Update is called once per frame
	void Update () 
    {
	    if(m_IsObjectNear == true && Input.GetButtonDown("Interact"))
        {
            if(m_IsOffState == true)
            {
                m_IsOffState = false;
                m_IsOnState = true;
                buttonRend.material.color = Color.red;
                Debug.Log("Switch is now in on state");
            }
            else if(m_IsOnState == true)
            {
                m_IsOffState = true;
                m_IsOnState = false;
                buttonRend.material.color = Color.blue;

                Debug.Log("Switch is now in off state");
            }
        }
	}
}
