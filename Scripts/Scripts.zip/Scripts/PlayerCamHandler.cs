﻿using UnityEngine;
using System.Collections;

public class PlayerCamHandler : MonoBehaviour {

    public float lookSensitivity = 5;
    public float lookSmoothDamp = 0.1f;
    [HideInInspector]
    public float yRotation;
    [HideInInspector]
    public float xRotation;
    [HideInInspector]
    public float currentYRotation;
    [HideInInspector]
    public float currentXRotation;
    [HideInInspector]
    public float yRotationV;
    [HideInInspector]
    public float xRotationV;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (GameManager.Instance.m_InMenu)
        {
            this.GetComponent<PlayerCamHandler>().enabled = false;
        }

        yRotation += Input.GetAxis("Mouse X") * lookSensitivity;
        xRotation += Input.GetAxis("Mouse Y") * lookSensitivity;

        xRotation = Mathf.Clamp(xRotation, -90, 90);

        currentXRotation = Mathf.SmoothDamp(currentXRotation, xRotation, ref xRotationV, lookSmoothDamp);
        currentYRotation = Mathf.SmoothDamp(currentYRotation, yRotation, ref yRotationV, lookSmoothDamp);

        transform.rotation = Quaternion.Euler(currentXRotation, currentYRotation, 0);
        

      


    }
}
