﻿using UnityEngine;
using System.Collections;
using System.Xml.Serialization;


public class PlayerMoveHandler : MonoBehaviour {

    public Camera playerCamera;
    public float movementSpeed;
    public float sprintSpeed;
    public float mouseSensitivity;
    public float jumpSpeed;
    public float forwardJumpSpeed;
    public float Gravity;
    public float pushPower;
    private Vector3 moveDirection = Vector3.zero;
    private Quaternion NewRot;
    bool isGrounded;
    

    // Use this for initialization
    void Start ()
    {

    }

    // Update is called once per frame
    void Update ()
    {
        CharacterController cc = GetComponent<CharacterController>();
        RaycastHit hit;
        Vector3 newRotation = this.transform.eulerAngles;
        newRotation.y = playerCamera.transform.eulerAngles.y;
        this.transform.eulerAngles = newRotation;

        if (Physics.Raycast(transform.position, transform.forward, out hit))
        {
            if(hit.transform.tag == "Door")
            {
                hit.transform.SendMessage("OpenDoor", transform.position);
            }
        }

        if(cc.isGrounded)
        {
            if(Input.GetButton("Sprint"))
            {
                movementSpeed = 10;
                //Debug.Log("Current movespeed is" + movementSpeed);
            }
            else
            {
                movementSpeed = 5;
               // Debug.Log("Current movespeed is" + movementSpeed);
            }

            float forwardSpeed = Input.GetAxis("Vertical") * movementSpeed;
            float sideSpeed = Input.GetAxis("Horizontal") * movementSpeed;

            moveDirection = new Vector3(sideSpeed, 0, forwardSpeed);
            moveDirection = transform.rotation * moveDirection;

            if (Input.GetButton("Jump"))
            {
                moveDirection.y = jumpSpeed;
                string message = "I'm Working as intended!";
                Debug.Log(message.Coloured(Colors.green));
            }
            
        }
        moveDirection.y -= Gravity * Time.deltaTime;
        cc.Move(moveDirection * Time.deltaTime); 

        //if (Input.GetButtonDown("Escape"))
        //{
        //    Time.timeScale = 0;
        //    GameManager.Instance.m_InMenu = true;
        //    PauseMenuHolder.SetActive(true);
        //}

        //if(Input.GetKeyDown(KeyCode.F))
        //{
        //    Camera.main.GetComponent<LevelTransition>().enabled = true;
        //}
    }

    //this is just so it handles pushing rigidbodies
    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Rigidbody body = hit.collider.attachedRigidbody;
        if (body == null || body.isKinematic)
            return;

        if (hit.moveDirection.y < -0.3F)
            return;

        Vector3 pushDir = new Vector3(hit.moveDirection.x, 0, hit.moveDirection.z);
        body.velocity = pushDir * pushPower;
    }

    
}








