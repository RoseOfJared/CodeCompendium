﻿using UnityEngine;
using System.Collections;

public class FallingTriggerRespawn : MonoBehaviour {

    public Transform SpawnPoint;
    //GameObject m_PlayerInstance;
    bool m_IsOutOfBounds;

    void OnTriggerEnter(Collider collide)
    {
        if(collide.tag == "Player")
        {
            m_IsOutOfBounds = true;
        }
    }

    private IEnumerator Respawn_cr()
    {
        GameManager.m_PlayerInstance.transform.position = SpawnPoint.position;
        yield return new WaitForSeconds(2);
        m_IsOutOfBounds = false;
    }

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
        if(m_IsOutOfBounds == true)
        {
            StartCoroutine(Respawn_cr());
        }
        
    }
}
